package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import config.MybatisSqlSessionFactory;
import dto.Account;

public class AccountDaoImpl implements AccountDao {

	@Override
	public void insertAccount(Account acc) throws Exception {
		SqlSession sqlSession = MybatisSqlSessionFactory.getSqlSessionFactory().openSession();
		try {
			sqlSession.insert("mapper.account.insertAccount",acc);
			sqlSession.commit();
		} catch(Exception e) {
			sqlSession.rollback();
			throw e;
		} finally {
			sqlSession.close();
		}
		

	}

	@Override
	public void updateAccount(Account acc) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public Account selectAccount(String id) throws Exception {
		Account acc = null;
		try(SqlSession sqlSession = MybatisSqlSessionFactory.getSqlSessionFactory().openSession()) {
			acc = sqlSession.selectOne("mapper.account.selectAccount", id);
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return null;
	}

	@Override
	public List<Account> selectAccountList() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

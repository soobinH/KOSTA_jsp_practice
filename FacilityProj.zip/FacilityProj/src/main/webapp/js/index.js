<c:set var="contextPath" value="${pageContext.request.contextPath }"/>


$(function() {
	$('#signUpBtn').click(function() {
		location.href = '${contextPath}/member/signUp';
	});
});
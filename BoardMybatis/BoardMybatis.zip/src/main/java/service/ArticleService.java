package service;

import java.util.List;

import javax.servlet.http.Part;

import dto.Article;

public interface ArticleService {
	//글작성
	Integer writeArticle(Article article, String realPath, Part ifile, Part dfile) throws Exception;
	//글상세
	Article detailArticle(Integer num) throws Exception;
	//글삭제
	void deleteArticle(Integer num) throws Exception;
	//글수정
	void modifyArticle(Article article, String realPath, Part ifile, Part dfile) throws Exception;
	//글목록(페이징)
	List<Article> articleList(Integer page) throws Exception;
}

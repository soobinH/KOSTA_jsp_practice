package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import config.MybatisSqlSessionFactory;
import dto.Article;

public class ArticleDaoImpl implements ArticleDao {

	@Override
	public Integer insertArticle(Article article) throws Exception {
		SqlSession sqlSession = MybatisSqlSessionFactory.getSqlSessionFactory().openSession();
		try {
			sqlSession.insert("mapper.article.insertArticle", article);
			sqlSession.commit();
		} catch(Exception e) {
			e.printStackTrace();
			sqlSession.rollback();
		} finally {
			sqlSession.close();
		}
		return article.getNum();
	}

	@Override
	public Article selectArticle(Integer num) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateArticle(Article article) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Article> articleList(Integer row) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
